"""Simple Streamlit web app for SMS spam detection."""
from pathlib import Path
from urllib.request import urlretrieve
from zipfile import ZipFile
import pandas as pd
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

DATA_URL = "https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip"
DATA_DIR = Path("data")
DATA_PATH = DATA_DIR / "SMSSpamCollection"
ZIP_PATH = DATA_DIR / "sms_spam_collection.zip"

@st.cache_resource
def train_model():
    DATA_DIR.mkdir(exist_ok=True)
    if not DATA_PATH.exists():
        urlretrieve(DATA_URL, ZIP_PATH)
        with ZipFile(ZIP_PATH, "r") as archive:
            member = next((n for n in archive.namelist()
                           if n.endswith("SMSSpamCollection")), None)
            if member is None:
                raise FileNotFoundError("Dataset file was not found.")
            DATA_PATH.write_bytes(archive.read(member))
    data = pd.read_csv(DATA_PATH, sep="\t", header=None,
                       names=["label", "message"], encoding="utf-8").dropna()
    X_train, X_test, y_train, y_test = train_test_split(
        data["message"], data["label"], test_size=0.2,
        random_state=42, stratify=data["label"]
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer()),
        ("classifier", MultinomialNB())
    ])
    model.fit(X_train, y_train)
    score = accuracy_score(y_test, model.predict(X_test))
    return model, len(data), score

st.set_page_config(page_title="SMS Spam Detector", page_icon="📩")
st.title("📩 SMS Spam Detection")
st.write("Enter a text message to predict whether it is spam or legitimate.")
st.caption("Machine Learning: TF-IDF + Multinomial Naive Bayes")

try:
    with st.spinner("Loading dataset and training the model..."):
        model, total_messages, accuracy = train_model()
    st.metric("Dataset messages", f"{total_messages:,}")
    st.metric("Test-set accuracy", f"{accuracy * 100:.2f}%")
    message = st.text_area("Enter your message", placeholder="Congratulations! You won a prize...")
    if st.button("Check message", type="primary"):
        if not message.strip():
            st.warning("Please enter a message first.")
        else:
            prediction = model.predict([message])[0]
            if prediction == "spam":
                st.error("Prediction: SPAM")
            else:
                st.success("Prediction: NOT SPAM (HAM)")
            st.caption("This is a prediction, not a guarantee. Review suspicious messages carefully.")
except Exception as exc:
    st.error("The model could not load. Check your internet connection and try again.")
    st.caption(f"Technical detail: {exc}")
