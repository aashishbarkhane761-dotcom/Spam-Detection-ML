"""
SMS Spam Detection using TF-IDF and Multinomial Naive Bayes.
Downloads the UCI SMS Spam Collection dataset automatically if needed.
Run: python spam_detection.py
"""
from pathlib import Path
from urllib.request import urlretrieve
from zipfile import ZipFile
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

DATA_URL = "https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip"
DATA_DIR = Path("data")
ZIP_PATH = DATA_DIR / "sms_spam_collection.zip"
DATA_PATH = DATA_DIR / "SMSSpamCollection"

def load_dataset():
    DATA_DIR.mkdir(exist_ok=True)
    if not DATA_PATH.exists():
        print("Downloading the UCI SMS Spam Collection dataset...")
        urlretrieve(DATA_URL, ZIP_PATH)
        with ZipFile(ZIP_PATH, "r") as archive:
            member = next((n for n in archive.namelist()
                           if n.endswith("SMSSpamCollection")), None)
            if member is None:
                raise FileNotFoundError("SMSSpamCollection was not found in the dataset archive.")
            DATA_PATH.write_bytes(archive.read(member))
    data = pd.read_csv(DATA_PATH, sep="\t", header=None,
                       names=["label", "message"], encoding="utf-8")
    data = data.dropna()
    data["label"] = data["label"].str.lower().str.strip()
    return data

def main():
    data = load_dataset()
    X_train, X_test, y_train, y_test = train_test_split(
        data["message"], data["label"], test_size=0.2,
        random_state=42, stratify=data["label"]
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer()),
        ("classifier", MultinomialNB())
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    print("\n=== SMS SPAM DETECTION MODEL ===")
    print(f"Dataset messages: {len(data)}")
    print(f"Test accuracy: {accuracy_score(y_test, predictions) * 100:.2f}%")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, zero_division=0))
    print("Confusion matrix (labels: ham, spam):")
    print(confusion_matrix(y_test, predictions, labels=["ham", "spam"]))
    print("\nTry your own message. Type 'exit' to stop.")
    while True:
        try:
            message = input("\nEnter an SMS: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break
        if message.lower() == "exit":
            break
        if not message:
            print("Please enter a message.")
            continue
        result = model.predict([message])[0]
        print("Prediction:", "SPAM" if result == "spam" else "NOT SPAM (HAM)")

if __name__ == "__main__":
    main()
