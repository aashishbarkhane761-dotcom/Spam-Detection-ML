# SMS Spam Detection Using Machine Learning

A beginner-friendly college project that classifies SMS messages as **spam** or **ham (not spam)** using TF-IDF text features and a Multinomial Naive Bayes classifier.

## Features
- Automatically downloads the SMS Spam Collection dataset from the UCI Machine Learning Repository.
- Splits data into training and test sets (80% / 20%).
- Trains a TF-IDF + Multinomial Naive Bayes pipeline.
- Reports accuracy, precision, recall, F1-score and a confusion matrix.
- Lets the user test their own messages in the command line.
- Includes an optional Streamlit web interface.

## Dataset
The UCI SMS Spam Collection contains 5,574 labeled SMS messages.
Source: https://archive.ics.uci.edu/dataset/228/sms+spam+collection

Please retain attribution to the dataset source. Dataset terms and citation details are available on the UCI page.

## Project structure
```text
Spam-Detection-ML/
├── spam_detection.py
├── app.py
├── requirements.txt
├── README.md
└── .gitignore
```
The dataset is downloaded into `data/` the first time the code runs, so it does not need to be committed to GitHub.

## Run locally
Python 3.9 or newer is recommended.

```bash
pip install -r requirements.txt
python spam_detection.py
```

## Run the web app
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Run in Google Colab (Android-friendly)
1. Open https://colab.research.google.com/
2. Create a new notebook.
3. Run `!pip install pandas scikit-learn`
4. Paste the code from `spam_detection.py` into a code cell and run it. The dataset will download automatically.
5. Alternatively, upload this project to GitHub first, then use Colab to open the `.py` file and copy the code into a cell.

## Methodology
1. Load labeled messages.
2. Separate messages (`X`) from labels (`y`).
3. Split the dataset into training and testing data using stratification.
4. Convert text to TF-IDF features.
5. Train the Multinomial Naive Bayes classifier.
6. Evaluate using accuracy, precision, recall, F1-score and confusion matrix.
7. Predict a new message's label.

## Limitations
- The dataset is primarily English SMS; Hindi, Hinglish and newer spam styles may be classified less reliably.
- Test accuracy is measured on a held-out portion of this dataset and does not guarantee real-world performance.
- Do not rely on this educational model as the sole basis for security decisions.

## Technologies
Python, Pandas, Scikit-learn, TF-IDF, Multinomial Naive Bayes, Streamlit, GitHub.
